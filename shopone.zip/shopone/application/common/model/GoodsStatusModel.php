<?php
namespace app\common\model;
use think\Model;
class GoodsStatusModel extends Model
{
	protected $table = 'my_goods_status';
	protected $pk = 'sid';
}