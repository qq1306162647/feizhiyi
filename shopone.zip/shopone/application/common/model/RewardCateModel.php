<?php
namespace app\common\model;
use think\Model;
use app\index\controller\Wx;
class RewardCateModel extends Model
{
	protected 	$table = 'my_reward_cate';
	protected 	$pk = 'cid';

	
}