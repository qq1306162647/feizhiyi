<?php
namespace app\common\model;
use think\Model;
use app\index\controller\Wx;
class OrderStatusModel extends Model
{
	protected 	$table = 'my_order_status';
	protected 	$pk = 'sid';

	
}